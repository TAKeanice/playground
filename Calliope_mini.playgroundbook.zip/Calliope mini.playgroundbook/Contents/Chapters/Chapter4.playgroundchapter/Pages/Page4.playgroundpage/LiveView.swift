import UIKit
import PlaygroundSupport

let dashBoardController: DashBoardViewController = DashBoardViewController("4-4", [.RGB], [], [.Noise])
PlaygroundPage.current.liveView = dashBoardController
