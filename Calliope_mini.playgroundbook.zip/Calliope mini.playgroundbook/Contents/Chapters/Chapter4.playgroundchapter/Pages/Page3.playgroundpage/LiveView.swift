import UIKit
import PlaygroundSupport

let dashBoardController: DashBoardViewController = DashBoardViewController("4-3", [.RGB, .Sound], [.Pin], [])
PlaygroundPage.current.liveView = dashBoardController
