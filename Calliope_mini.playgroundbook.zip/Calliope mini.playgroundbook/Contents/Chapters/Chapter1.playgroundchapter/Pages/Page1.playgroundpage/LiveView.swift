import UIKit
import PlaygroundSupport

let dashBoardController: DashBoardViewController = DashBoardViewController("1-1", [.Display], [], [])
PlaygroundPage.current.liveView = dashBoardController

