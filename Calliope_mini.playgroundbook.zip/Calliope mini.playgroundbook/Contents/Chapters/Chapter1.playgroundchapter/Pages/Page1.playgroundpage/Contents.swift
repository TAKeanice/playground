//:#localized(key: "cc.calliope.miniplaygroundbook.Inputs001")

//#-hidden-code
import Foundation
import PlaygroundSupport
//#-end-hidden-code

//#-hidden-code
playgroundPrologue()
//#-end-hidden-code

//#-code-completion(everything, hide)
display.show(text: "/*#-editable-code*/<#T##string##String#>/*#-end-editable-code*/")

//#-hidden-code
playgroundEpilogue( BookProgramOutputString.assessment )
//#-end-hidden-code
