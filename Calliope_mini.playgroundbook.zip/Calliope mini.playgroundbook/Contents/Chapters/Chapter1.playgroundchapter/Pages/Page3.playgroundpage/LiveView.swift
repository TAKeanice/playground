import UIKit
import PlaygroundSupport

let dashBoardController: DashBoardViewController = DashBoardViewController("1-3", [.Display], [], [])
PlaygroundPage.current.liveView = dashBoardController

