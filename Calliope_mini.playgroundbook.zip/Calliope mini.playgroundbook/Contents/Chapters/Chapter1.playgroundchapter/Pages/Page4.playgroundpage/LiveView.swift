import UIKit
import PlaygroundSupport

let dashBoardController: DashBoardViewController = DashBoardViewController("1-4", [.Display], [], [])
PlaygroundPage.current.liveView = dashBoardController
