import UIKit
import PlaygroundSupport

let dashBoardController: DashBoardViewController = DashBoardViewController("2-2", [.Display], [.ButtonB], [])
PlaygroundPage.current.liveView = dashBoardController
