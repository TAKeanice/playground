import UIKit
import PlaygroundSupport

let dashBoardController: DashBoardViewController = DashBoardViewController("2-4", [.Display], [.Pin], [])
PlaygroundPage.current.liveView = dashBoardController
