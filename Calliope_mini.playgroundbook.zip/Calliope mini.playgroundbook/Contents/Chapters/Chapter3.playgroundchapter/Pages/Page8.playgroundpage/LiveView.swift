import UIKit
import PlaygroundSupport

let dashBoardController: DashBoardViewController = DashBoardViewController("3-8", [.Display], [.Shake], [])
PlaygroundPage.current.liveView = dashBoardController
