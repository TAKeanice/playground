import UIKit
import PlaygroundSupport

let dashBoardController: DashBoardViewController = DashBoardViewController("3-6", [.Display], [], [])
PlaygroundPage.current.liveView = dashBoardController
