import UIKit
import PlaygroundSupport

let dashBoardController: DashBoardViewController = DashBoardViewController("3-3", [.Display], [], [])
PlaygroundPage.current.liveView = dashBoardController
